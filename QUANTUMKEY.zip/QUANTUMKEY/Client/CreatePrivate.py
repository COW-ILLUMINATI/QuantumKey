from ClientMain import *
createPrivate()